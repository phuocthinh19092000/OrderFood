package com.example.revision;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.revision.databinding.ActivityDetailBinding;
import com.example.revision.databinding.ActivityMainBinding;

public class DetailActivity extends AppCompatActivity {


    private ActivityDetailBinding binding;
    //private  TextView tv;
    private MyViewModel Model;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailBinding.inflate(getLayoutInflater());
        View v  = binding.getRoot();
        setContentView(v);

        //tv = findViewById(R.id.textView);

        Intent intent = getIntent();
        if (intent!=null) {
            String t1 = intent.getStringExtra("data");
            binding.tv1.setText(t1);
        }
    }

}